/**
  Generated Main Source File
  Company:
    Microchip Technology Inc.
  File Name:
    main.c
  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs 

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs  - 1.45
        Device            :  PIC16LF1459
        Driver Version    :  2.00
    The generated drivers are tested against the following:
        Compiler          :  XC8 1.35
        MPLAB             :  MPLAB X 3.40
*/


#include "mcc_generated_files/mcc.h"
#include "BackscatterComm.h"
#include "main.h"
//#include "pic16lf1459.h"
 

    char  packet0[PACKETLENGTH_OOK+DUMMYBIT]=0; 
    char  packet1[PACKETLENGTH+DUMMYBIT]=0;        
    int sleep=0;
    int SENSORID=0;
    int OOK=1;
    
void main(void)
{
    // initialize the device
    SYSTEM_Initialize();
    
     if (sleep==1)
    {    
       // Enable the Global Interrupts
       INTERRUPT_GlobalInterruptEnable();
    }
    else
    {
      // Disable the Global Interrupts
      INTERRUPT_GlobalInterruptDisable();
    }   
    //ADCON0 = 0x00;
    while (1)
    {
         
        adc_result_t sensor= ADC_GetConversion(channel_AN7);    
         sensor=483;
         
         ADCON0 = 0x00; 
         
         
        
         if (OOK==1)
         {   
                  
            createPacketFM0(packet0,SENSORID, sensor); //Packet with data from sensor 1
            DACCON0 = 0x20;
            backscatter_transmit_packet_FM0(packet0, PACKETLENGTH_OOK+DUMMYBIT);
         }
         else
         {
           createPacket_PAM(packet1 ,SENSORID, sensor); //Packet with data from sensor 1 
          //DAC_Initialize();
          DACCON1 = 0;  //G1
          backscatter_transmit_packet_4PAM(packet1, PACKETLENGTH); 
          //DACCON1 = 6;  //G2
           // DACCON0 = 0x20;  
         
         }

        
        
           if (sleep==1)
           {     
            SLEEP(); // go to sleep ->interupt at pin 15 
           }
           else
           {
              int waitind; 
              for(waitind = 0; waitind<45; waitind++){  
                _nop();
                _nop();
               }
           }    
    }
}


void createPacketFM0(unsigned char  *txdata, int SensorID, int16_t Value)
{
     int c, k;
    // Create the preamble sequence (1 0 1 0 1 0....)
       txdata[0] = '1';
       txdata[1] = '0';
       txdata[2] = '1';
       txdata[3] = '0';
       txdata[4] = '1';
       txdata[5] = '0';
       txdata[6] = '1';
       txdata[7] = '1';
       txdata[8] = '1';
       txdata[9] = '1';
       //NODE_ID
       
       txdata[10] = '0';
       txdata[11] = '1';
       //SEnsor ID 
       if (SensorID==0)
       {
          txdata[12] = '0';
       }
       else
       {
          txdata[12] = '1';
       }    
        txdata[13] = '1';
        
       //convert int to binary 
		for(c = INFOWORD_LENGTH - 1; c >= 0; c--){
				k = Value >> c;
                 txdata[(PREAMBLE_LENGTH_OOK +ID_LENGTH+UTILITY_LENGTH) + INFOWORD_LENGTH - c - 1] = (k & 1) ? '1' : '0';
		}
       txdata[PACKETLENGTH_OOK-1] = '1';
}


void createPacket_PAM(unsigned char  *txdata, int SensorID, int16_t Value)
{
     int c, k;
      // Create the preamble sequence (1 0 1 0 1 0....)
      //Premble_Data_bits=[0 1  1 1  1 0  0 0  0 1];
       //-----------G1(00)------------G2(01)-----------G3(11)--------------G4(10)----------
       txdata[0] = '1'; 
       txdata[1] = '0';
       
       txdata[2] = '0';
       txdata[3] = '0';
       
       txdata[4] = '1';
       txdata[5] = '0';
       
       txdata[6] = '0';
       txdata[7] = '0';
       
       txdata[8] = '1';
       txdata[9] = '0';
       
       
       txdata[10] = '0';
       txdata[11] = '1';
       
       txdata[12] = '1';
       txdata[13] = '1';
       
       //NODE_ID
       txdata[PREAMBLE_LENGTH] = '0';
       txdata[PREAMBLE_LENGTH+1] = '0';
       
       //SEnsor ID 
       if (SensorID==0)
       {
          txdata[PREAMBLE_LENGTH+2] = '0';
          txdata[PREAMBLE_LENGTH+3] = '1';
       }
       else
       {
           txdata[PREAMBLE_LENGTH+2] = '1';
           txdata[PREAMBLE_LENGTH+3] = '0';
       }    
       
       //convert int to binary 
		for(c = INFOWORD_LENGTH - 1; c >= 0; c--){
				k = Value >> c;
                 txdata[(PREAMBLE_LENGTH +ID_LENGTH+UTILITY_LENGTH) + INFOWORD_LENGTH - c -1] = (k & 1) ? '1' : '0';
		}
       txdata[PACKETLENGTH] = '1';
}

// for 32 kHz Clock Tymbol=5.8 ms => 10.2 kbps
void backscatter_transmit_packet_4PAM(unsigned char  *txdata, unsigned char  length)
{    
    //Create the reflection coefficients  
    //Follow Grey code
     //-----------G1(00)------------G2(01)-----------G3(11)--------------G4(10)----------
    int ii = 0;
	while(ii < length)
    {
        if(txdata[ii] == '0')     
		{
               if(txdata[ii+1] == '0') 
               {
                     DACCON1 = 0;  //G1
                     _nop();
               }
               else
               {
                     DACCON1 = 6;  //G2
                     _nop();
                     _nop();
                     _nop();
               }
		}
        else 
		{  
               if (txdata[ii+1] == '1') 
               {    
                   DACCON1 = 7;   //G3
                   _nop();
                   _nop();
                   _nop();
                   _nop();
                   
               }
               else
               { 
                   DACCON1 = 14;  //G4
                   _nop();
                   _nop();
                   _nop();
                   _nop();
                   _nop();
                   _nop();
               
               }
		}
       ii=ii+2;
    }
     
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     
     DACCON1 = 0;
}

 void backscatter_transmit_packet_FM0(unsigned char  *txdata, unsigned char  length)
{
    int ii = 0;
   // LATC4=0;
	for(ii = 0; ii<length; ii++)
    {
	    LATC4=~LATC4;
        if(txdata[ii] == '1')     //G1
		{ 
               _nop();
               _nop(); 
		}
        if(txdata[ii] == '0') 
		{  

              _nop();
              LATC4=~LATC4;
              _nop();    
		}      
    }
    LATC4=0;
}
 
 
 // for 1 MHz Clock Tymbol=196 us => 10.2 kbps
 
/*  void backscatter_transmit_packet_4PAM(unsigned char  *txdata, unsigned char  length)
{    
    //Create the reflection coefficients  
    //Follow Grey code
     //-----------G1(00)------------G2(01)-----------G3(11)--------------G4(10)----------
    int ii = 0;
	while(ii < length)
    {
        if(txdata[ii] == '0')     
		{
               if(txdata[ii+1] == '0') 
               {
                     DACCON1 = 0;  //G1
                     _nop();
               }
               else
               {
                     DACCON1 = 6;  //G2
                     _nop();
                     _nop();
                     _nop();
               }
		}
        else 
		{  
               if (txdata[ii+1] == '1') 
               {    
                   DACCON1 = 7;   //G3
                   _nop();
                   _nop();
                   _nop();
                   _nop();
                   
               }
               else
               { 
                   DACCON1 = 14;  //G4
                   _nop();
                   _nop();
                   _nop();
                   _nop();
                   _nop();
                   _nop();
                   
               }
		}
       ii=ii+2;
    }
     
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();
     _nop();

     DACCON1 = 0;
}
  */