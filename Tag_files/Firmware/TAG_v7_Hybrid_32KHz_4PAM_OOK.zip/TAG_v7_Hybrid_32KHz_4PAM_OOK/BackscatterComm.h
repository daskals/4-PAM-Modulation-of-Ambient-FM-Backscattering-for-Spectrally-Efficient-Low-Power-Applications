/* 
 * File:   BackscatterComm.h
 * Author: Daskals
 *
 * Created on November 17, 2017, 10:56 AM
 */

#ifndef BACKSCATTERCOMM_H
#define	BACKSCATTERCOMM_H

#ifdef	__cplusplus
extern "C" {
#endif

#define TAG ID 1
    
#define PREAMBLE_LENGTH_OOK 10   
#define PREAMBLE_LENGTH 14
#define ID_LENGTH 2
#define UTILITY_LENGTH 2
#define DUMMYBIT 1

#define HEADER_LENGTH_OOK (PREAMBLE_LENGTH_OOK+ID_LENGTH+UTILITY_LENGTH)
#define HEADER_LENGTH (PREAMBLE_LENGTH+ID_LENGTH+UTILITY_LENGTH)

//Uncoded
#define INFOWORD_LENGTH 10
#define PACKETLENGTH_OOK (HEADER_LENGTH_OOK+INFOWORD_LENGTH)
#define PACKETLENGTH (HEADER_LENGTH+INFOWORD_LENGTH)


#ifdef	__cplusplus
}
#endif

#endif	/* BACKSCATTERCOMM_H */

